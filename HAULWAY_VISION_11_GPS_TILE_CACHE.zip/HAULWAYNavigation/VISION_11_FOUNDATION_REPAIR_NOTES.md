# HAULWAY VISION 11 – GPS and map rendering foundation

## Changes in this package

### GPS source priority
- When Android reports an enabled GPS provider and fine-location permission is granted, HAULWAY subscribes to GNSS/GPS only.
- Network location is used only as a fallback when the GPS provider is unavailable.
- Cached location is used only when no older than 30 seconds.
- Live fixes older than 6 seconds or with reported accuracy worse than 50 metres are ignored for navigation updates.
- GPS update request interval is 1 second with a 0.5 metre minimum displacement; network fallback is 3 seconds / 10 metres.

### Map tile rendering
- Added an in-memory tile cache keyed by provider, zoom, x and y.
- Existing visible tiles remain on screen while replacement tiles load.
- Tiles are reused rather than downloaded and recreated on every map render.
- Old off-screen tiles are pruned after the replacement viewport is ready.
- Vehicle marker transition shortened to 220 ms to reduce visible lag between GPS fixes.

## Validation
- Extracted embedded map JavaScript passed `node --check`.
- Full Android Gradle build was attempted, but the build environment could not resolve `services.gradle.org` to download the configured Gradle 9.6.0 distribution. Therefore APK compilation is NOT verified in this environment.
- No APK is included. Run GitHub Actions / Android Studio build before installing.

## Important limitations
- This is a foundation repair, not a complete implementation of all requested navigation features.
- GNSS quality still depends on the tablet's antenna, sky visibility, Android location settings and device hardware.
- Automatic rerouting still depends on a valid ORS API key, network access and a successful HGV routing response.
- Speed-limit recognition is not implemented by this package; no speed limit is fabricated.
