# HAULWAY Vision 11 — navigation foundation repair

This update is a focused first engineering pass on the live-navigation failures reported during road testing.

## Implemented in source

- Reject stale location fixes older than 12 seconds.
- Reject very poor accuracy fixes (>65 m) and physically implausible GPS jumps (>55 m/s over short intervals).
- Prefer GPS updates at 500 ms / 0.5 m and keep the network provider as a slower backup at 2.5 s / 5 m.
- Smooth the displayed GPS speed to reduce visible fluctuations; derive a fallback speed from consecutive accepted fixes when the provider omits speed.
- Detect sustained off-route movement using an accuracy-aware threshold.
- Automatically request a new HGV route from the actual live GPS coordinate to the saved destination, with a 20-second request throttle. Requires a valid ORS key and network access.
- Preserve the FOLLOW camera when a replacement route arrives.
- Remove the artificial 12-degree map pitch that was obscuring the road view.
- Smooth vehicle-marker movement independently from tile rendering.
- Remove the grey `travelled` polyline that was being drawn over the blue route and visually obscuring the route highlight.
- Remove the Great Britain-only filter from Photon autocomplete results.
- Remove the large manoeuvre card from the map; manoeuvres remain in the right information panel.
- Add a full-width distance / ETA-duration strip at the bottom of the right information panel.
- Add a GitHub Actions build workflow. It caches the debug signing key between builds to reduce APK update-signature conflicts.

## Not yet implemented / not verified

- Road-name reverse geocoding bubble under the live location marker.
- Official/current road speed-limit data and speed-limit warnings. No fabricated speed limits are displayed.
- Full-screen LUPE category browser (homes, businesses, POIs) and robust postcode-to-street/house-number category refinement.
- Live traffic hazard ingestion and POI discovery along the active route.
- Full end-to-end automatic navigation state machine and road-test validation.
- Verified HGV restrictions beyond the route provider's returned route calculation.

## Build and validation status

- Embedded map JavaScript passed `node --check` after extracting the script and substituting the Android build-time constants.
- Kotlin parser check reported no syntax/parse errors.
- A full Gradle build could not be run in this environment because the Gradle 9.6 distribution could not be downloaded (network DNS unavailable). GitHub Actions must provide the authoritative Android build result.
- Do not treat this source update as road-safe or production-ready until the generated APK is tested on the Lenovo and Samsung devices and then validated on a controlled route.

## GitHub Actions

The new workflow builds `app-debug.apk` on pushes to `main` and on manual dispatch. Configure repository secrets:

- `ORS_API_KEY` — required for HGV route calculation and automatic rerouting.
- `CARTO_API_KEY` — optional map styles.
- `GOOGLE_MAPS_API_KEY`, `GOOGLE_STREETVIEW_API_KEY`, `MAPILLARY_ACCESS_TOKEN` — optional integrations.

The workflow caches `~/.android/debug.keystore` to keep the debug APK signing identity stable between CI runs. If the cache is deleted, Android may require uninstalling the previously installed APK before installing the newly signed one.
